﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMS_BASE.Models
{
    public class InvoiceDetails
    {
        public string Invoice_Date { get; set; }
        public string Invoice_Amt { get; set; }
        public string Invoice_Remark { get; set; }
    }
}
