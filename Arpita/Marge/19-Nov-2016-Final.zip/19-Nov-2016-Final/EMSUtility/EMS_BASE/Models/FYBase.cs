﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_BASE.Models
{
    public class FYBase
    {
        public string FinancialYearId { get; set; }

        public string FinancialYear { get; set; }

        public bool CurrentFlag { get; set; }
    }
}
