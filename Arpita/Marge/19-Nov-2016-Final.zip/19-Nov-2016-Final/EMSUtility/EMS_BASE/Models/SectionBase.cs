﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_BASE.Models
{
    public class SectionBase
    {
        public int SectionId { get; set; }

        public string SectionName { get; set; }
    }
    
}
