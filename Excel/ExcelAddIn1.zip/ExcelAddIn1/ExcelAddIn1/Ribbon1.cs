﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;
using System.Windows.Forms;

namespace ExcelAddIn1
{
    public partial class Ribbon1
    {
        Microsoft.Office.Interop.Excel.Workbook xlWorkBook;

        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            
                       
        }
        

        private void btn_Login_Click(object sender, RibbonControlEventArgs e)
        {
            LoginForm loginFrom = new LoginForm();
            loginFrom.Show();


            Microsoft.Office.Interop.Excel.Window window = e.Control.Context;



            var xlSheets = xlWorkBook.Sheets as Microsoft.Office.Interop.Excel.Sheets;

            Microsoft.Office.Interop.Excel.Worksheet activeWorksheet = (Microsoft.Office.Interop.Excel.Worksheet)xlSheets.Add(xlSheets[4], Type.Missing, Type.Missing, Type.Missing);

            activeWorksheet.Name = "TheBeastSheet";

           // Microsoft.Office.Interop.Excel.Worksheet activeWorksheet = ((Microsoft.Office.Interop.Excel.Worksheet)window.Application.ActiveSheet);
            
            Microsoft.Office.Interop.Excel.Range firstRow = activeWorksheet.get_Range("A1");
            firstRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown);
            Microsoft.Office.Interop.Excel.Range newFirstRow = activeWorksheet.get_Range("A1");
            newFirstRow.Value2 = "This";

            Microsoft.Office.Interop.Excel.Range SecRow = activeWorksheet.get_Range("A2");
            SecRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown);
            Microsoft.Office.Interop.Excel.Range newSecRow = activeWorksheet.get_Range("A2");
            newSecRow.Value2 = "text";

            Microsoft.Office.Interop.Excel.Range thirdRow = activeWorksheet.get_Range("A3");
            thirdRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown);
            Microsoft.Office.Interop.Excel.Range newthirdRow = activeWorksheet.get_Range("A3");
            newthirdRow.Value2 = "was";

            Microsoft.Office.Interop.Excel.Range forthRow = activeWorksheet.get_Range("A4");
            forthRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown);
            Microsoft.Office.Interop.Excel.Range newForthrow = activeWorksheet.get_Range("A4");
            newForthrow.Value2 = "added";
            //MessageBox.Show("Great Work.");

            Microsoft.Office.Interop.Excel.Range fifthRow = activeWorksheet.get_Range("A5");
            fifthRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown);
            Microsoft.Office.Interop.Excel.Range newfifthRow = activeWorksheet.get_Range("A5");
            newfifthRow.Value2 = "by";
            
            Microsoft.Office.Interop.Excel.Range sixthRow = activeWorksheet.get_Range("A6");
            sixthRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown);
            Microsoft.Office.Interop.Excel.Range newsixthRow = activeWorksheet.get_Range("A6");
            newsixthRow.Value2 = "using";

            Microsoft.Office.Interop.Excel.Range seventhRow = activeWorksheet.get_Range("A7");
            seventhRow.EntireRow.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftDown);
            Microsoft.Office.Interop.Excel.Range newseventhRow = activeWorksheet.get_Range("A7");
            newseventhRow.Value2 = "code";
                

        }
    }
}
